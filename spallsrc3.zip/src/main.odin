package main

import "core:fmt"
import "spall"

main :: proc() {
	source := `1 2 + print
.5 1. + print
-7 dup * print
10 3 mod print
`

	code, ok := spall.compile_source(source)
	if !ok {
		fmt.println("compile error:", spall.Compiler.error_string)
		return
	}

	spall.debug_print_code(&code)
}
