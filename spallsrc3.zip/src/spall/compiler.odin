package spall

import "core:fmt"


// Compiler state =================================================================================

// Compiler is package-local scratch state for building one Code object.
// VM is host-owned runtime state; Compiler is not.
Compiler := struct {
	code:         Code,
	error_string: string,
}{}


// Bytecode emission ==============================================================================

emit_inst :: proc(op: Op, arg: u32 = 0) {
	inst := Inst {
		op  = op,
		arg = arg,
	}

	append(&Compiler.code.bytecode, u32(inst))
	append(&Compiler.code.inst_lines, 0)
}


// Constants ======================================================================================

const_int :: proc(value: i64) -> u32 {
	append(&Compiler.code.const_pool, Value(value))
	return u32(len(Compiler.code.const_pool) - 1)
}

const_float :: proc(value: f64) -> u32 {
	append(&Compiler.code.const_pool, Value(value))
	return u32(len(Compiler.code.const_pool) - 1)
}


// Source compilation =============================================================================

compile_source :: proc(source: string) -> (Code, bool) {
	begin_lex(source)

	clear(&Compiler.code.bytecode)
	clear(&Compiler.code.inst_lines)
	clear(&Compiler.code.const_pool)
	Compiler.error_string = ""

	for {
		token := lex_next_token()

		switch token.kind {
		case .EOF:
			return Compiler.code, true

		case .ERROR:
			Compiler.error_string = token.value.(string)
			return {}, false

		case .INT:
			value := token.value.(i64)
			const_index := const_int(value)
			emit_inst(.PUSH_CONST, const_index)

		case .FLOAT:
			value := token.value.(f64)
			const_index := const_float(value)
			emit_inst(.PUSH_CONST, const_index)

		case .WORD:
			word := token.value.(string)

			switch word {
			case "+":
				emit_inst(.ADD)
			case "-":
				emit_inst(.SUB)
			case "*":
				emit_inst(.MUL)
			case "/":
				emit_inst(.DIV)
			case "mod":
				emit_inst(.MOD)

			case "dup":
				emit_inst(.DUP)
			case "drop":
				emit_inst(.DROP)
			case "swap":
				emit_inst(.SWAP)
			case "over":
				emit_inst(.OVER)

			case "print":
				emit_inst(.PRINT)

			case:
				Compiler.error_string = fmt.tprintf("unknown word: %s", word)
				return {}, false
			}
		}
	}
}


// Debug ==========================================================================================

op_to_string :: proc(op: Op) -> string {
	switch op {
	case .PUSH_CONST:
		return "PUSH_CONST"

	case .ADD:
		return "ADD"
	case .SUB:
		return "SUB"
	case .MUL:
		return "MUL"
	case .DIV:
		return "DIV"
	case .MOD:
		return "MOD"

	case .DUP:
		return "DUP"
	case .DROP:
		return "DROP"
	case .SWAP:
		return "SWAP"
	case .OVER:
		return "OVER"

	case .PRINT:
		return "PRINT"
	}

	return "UNKNOWN"
}

debug_print_code :: proc(code: ^Code) {
	fmt.println("CONSTANTS:")

	for index := 0; index < len(code.const_pool); index += 1 {
		value := code.const_pool[index]

		switch v in value {
		case i64:
			fmt.printf("  %04d %-6s %d\n", index, "INT", v)

		case f64:
			fmt.printf("  %04d %-6s %g\n", index, "FLOAT", v)

		case bool:
			text := "false"
			if v {
				text = "true"
			}

			fmt.printf("  %04d %-6s %s\n", index, "BOOL", text)
		}
	}

	fmt.println("")
	fmt.println("CODE:")

	for index := 0; index < len(code.bytecode); index += 1 {
		inst := Inst(code.bytecode[index])
		op_text := op_to_string(inst.op)

		if inst.op == .PUSH_CONST {
			fmt.printf("  %04d %-10s %d\n", index, op_text, inst.arg)
		} else {
			fmt.printf("  %04d %s\n", index, op_text)
		}
	}
}
