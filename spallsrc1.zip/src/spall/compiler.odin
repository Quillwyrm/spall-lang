package spall

Compiler := struct {
	code:         Code,
	error_string: string,
}{}

begin_compile :: proc() {
	clear(&Compiler.code.bytecode)
	clear(&Compiler.code.inst_lines)
	clear(&Compiler.code.const_pool)
	Compiler.error_string = ""
}

emit_inst :: proc(op: Op, arg: u32 = 0) {
	inst := Inst {
		op  = op,
		arg = arg,
	}

	append(&Compiler.code.bytecode, u32(inst))
	append(&Compiler.code.inst_lines, 0)
}

add_const :: proc(value: Value) -> u32 {
	append(&Compiler.code.const_pool, value)
	return u32(len(Compiler.code.const_pool) - 1)
}

compile_source :: proc(source: string) -> (Code, bool) {
	begin_lex(source)
	begin_compile()

	for {
		token := lex_next_token()

		switch token.kind {
		case .EOF:
			return Compiler.code, true

		case .ERROR:
			Compiler.error_string = token.value.(string)
			return {}, false

		case .INT:
			value := token.value.(i64)
			const_index := add_const(Value(value))
			emit_inst(.PUSH_CONST, const_index)

		case .FLOAT:
			value := token.value.(f64)
			const_index := add_const(Value(value))
			emit_inst(.PUSH_CONST, const_index)

		case .WORD:
			word := token.value.(string)

			switch word {
			case "+":
				emit_inst(.ADD)
			case "-":
				emit_inst(.SUB)
			case "*":
				emit_inst(.MUL)
			case "/":
				emit_inst(.DIV)
			case "mod":
				emit_inst(.MOD)

			case "dup":
				emit_inst(.DUP)
			case "drop":
				emit_inst(.DROP)
			case "swap":
				emit_inst(.SWAP)
			case "over":
				emit_inst(.OVER)

			case "print":
				emit_inst(.PRINT)

			case:
				Compiler.error_string = "unknown word"
				return {}, false
			}
		}
	}
}
