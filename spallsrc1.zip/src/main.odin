package main

import "spall"

main :: proc() {
	source :=
   `1 2 + print
	.5 1. -0.25 kebab-case mod
	- -7`

	spall.debug_print_tokens(source)
}
