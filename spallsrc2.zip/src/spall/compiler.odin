package spall


// Compiler state =================================================================================

// Compiler is package-local scratch state for building one Code object.
//
// Unlike State, this is not a host-owned runtime object. It is just the
// current compile pass context.
Compiler := struct {
	code:         Code,
	error_string: string,
}{}


// Bytecode emission ==============================================================================

emit_inst :: proc(op: Op, arg: u32 = 0) {
	inst := Inst {
		op  = op,
		arg = arg,
	}

	append(&Compiler.code.bytecode, u32(inst))
	append(&Compiler.code.inst_lines, 0)
}


// Constants ======================================================================================

const_int :: proc(value: i64) -> u32 {
	append(&Compiler.code.const_pool, Value(value))
	return u32(len(Compiler.code.const_pool) - 1)
}

const_float :: proc(value: f64) -> u32 {
	append(&Compiler.code.const_pool, Value(value))
	return u32(len(Compiler.code.const_pool) - 1)
}


// Source compilation =============================================================================

compile_source :: proc(source: string) -> (Code, bool) {
	begin_lex(source)

	clear(&Compiler.code.bytecode)
	clear(&Compiler.code.inst_lines)
	clear(&Compiler.code.const_pool)
	Compiler.error_string = ""

	for {
		token := lex_next_token()

		switch token.kind {
		case .EOF:
			return Compiler.code, true

		case .ERROR:
			Compiler.error_string = token.value.(string)
			return {}, false

		case .INT:
			value := token.value.(i64)
			const_index := const_int(value)
			emit_inst(.PUSH_CONST, const_index)

		case .FLOAT:
			value := token.value.(f64)
			const_index := const_float(value)
			emit_inst(.PUSH_CONST, const_index)

		case .WORD:
			word := token.value.(string)

			switch word {
			case "+":
				emit_inst(.ADD)
			case "-":
				emit_inst(.SUB)
			case "*":
				emit_inst(.MUL)
			case "/":
				emit_inst(.DIV)
			case "mod":
				emit_inst(.MOD)

			case "dup":
				emit_inst(.DUP)
			case "drop":
				emit_inst(.DROP)
			case "swap":
				emit_inst(.SWAP)
			case "over":
				emit_inst(.OVER)

			case "print":
				emit_inst(.PRINT)

			case:
				Compiler.error_string = "unknown word"
				return {}, false
			}
		}
	}
}
